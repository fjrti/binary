#!/usr/bin/env bash

#
# Usage: ngx.sh { start | stop | reload | status | check}
# fjrti@163.com
#

set -o errexit
set -o errtrace
set -o nounset
set -o pipefail

function trap_err() {
    trap - ERR
    set +o errexit
    set +o pipefail

    if [[ $# -eq 1 && $1 =~ ^[0-9]+$ ]]; then
        exit "$1"
    else
        exit 1
    fi
}

function trap_exit() {
    cd "$orig_cwd"
    printf '%b' "$(tput sgr0 || true)"
}

function script_init() {
    readonly orig_cwd="$PWD"
    readonly script_path="${BASH_SOURCE[0]}"
    readonly script_dir="$(dirname "$script_path")"
    readonly script_name="$(basename "$script_path")"
}

function script_usage() {
    printf "Usage: $script_name { start | stop | reload | status | check } \n"
}

function get_status() {
    local pidfile=$script_dir/temp/nginx.pid
    local pid=$(test -f $pidfile && cat $pidfile)
    local status="\033[1;31m[ failed ]\033[0m"

    if [ "$pid" -gt 0 ] 2>/dev/null; then
        ps -p $pid &> /dev/null
        [ $? -eq 0 ] && status="\033[1;32m[ running ]\033[0m"
    fi

    echo -e "ngnix status                      $status"
}

function parse_params() {
    local param
    local bin="$script_dir/sbin/nginx -p $script_dir"
   
    if [[ $# -ne 1 ]]; then
        script_usage
        exit 1
    fi
  
    while [[ $# -gt 0 ]]; do
        param="$1"
        shift
        case $param in
            start)
                $bin
                get_status
                ;;
            stop)
                $bin -s stop
                ;;
            reload)
                $bin -s reload
                ;;
            status|st)
                get_status
                ;;
            check)
                $bin -t
                ;;
            *)
                echo -e "Invalid parameter was provided: \033[1;31m$param\033[0m " && exit 1
                ;;
            esac
    done
}

function main() {
    trap "trap_err" ERR
    trap "trap_exit" EXIT
    script_init
    parse_params "$@"
}

main "$@"

